/*
 * Clone Lab - part2.h
 * 
 * Ecole polytechnique de Montreal, 2018
 */

#ifndef _PART2_H
#define _PART2_H

void part2();

#endif
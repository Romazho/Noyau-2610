/*
 * Comm Lab - puzzle3.h
 * 
 * Ecole polytechnique de Montreal, 2018
 */

#ifndef _PUZZLE3_H
#define _PUZZLE3_H

void puzzle3();

#endif